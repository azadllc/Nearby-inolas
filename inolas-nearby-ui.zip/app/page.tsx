'use client'

import { Radar } from 'lucide-react'
import { useState } from 'react'
import { BottomNav, type TabKey } from '@/components/nearby/bottom-nav'
import { ChatScreen } from '@/components/nearby/chat-screen'
import { ConnectionSheet } from '@/components/nearby/connection-sheet'
import type { NearbyDevice } from '@/components/nearby/data'
import { HomeScreen } from '@/components/nearby/home-screen'
import { SettingsScreen } from '@/components/nearby/settings-screen'
import type { ConnectivityState } from '@/components/nearby/status-bar'
import { ThemeToggle } from '@/components/nearby/theme-toggle'

const tabTitles: Record<TabKey, { title: string; subtitle: string }> = {
  home: { title: 'Inolas Nearby', subtitle: 'Offline · No internet required' },
  chat: { title: 'Offline Share', subtitle: 'Encrypted peer-to-peer channel' },
  settings: { title: 'Settings', subtitle: 'Profile, preferences & history' },
}

export default function Page() {
  const [tab, setTab] = useState<TabKey>('home')
  const [scanning, setScanning] = useState(true)
  const [incoming, setIncoming] = useState<NearbyDevice | null>(null)
  const [connectivity, setConnectivity] = useState<ConnectivityState>({
    bluetooth: true,
    wifi: true,
    visible: true,
  })

  const header = tabTitles[tab]

  return (
    <div className="mx-auto flex min-h-dvh max-w-md flex-col bg-background">
      {/* App bar */}
      <header className="sticky top-0 z-30 flex items-center justify-between gap-3 border-b border-border bg-background/80 px-5 py-4 backdrop-blur-lg">
        <div className="flex items-center gap-3">
          <span className="flex size-10 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg shadow-primary/25">
            <Radar className="size-5" />
          </span>
          <div>
            <h1 className="text-base font-bold leading-tight tracking-tight text-foreground">
              {header.title}
            </h1>
            <p className="text-xs text-muted-foreground">{header.subtitle}</p>
          </div>
        </div>
        <ThemeToggle />
      </header>

      {/* Screens */}
      <main className="flex-1 px-5 py-5">
        {tab === 'home' && (
          <HomeScreen
            connectivity={connectivity}
            onConnectivityChange={setConnectivity}
            scanning={scanning}
            onScanToggle={() => setScanning((v) => !v)}
            onSelectDevice={setIncoming}
          />
        )}
        {tab === 'chat' && <ChatScreen />}
        {tab === 'settings' && <SettingsScreen />}
      </main>

      <BottomNav active={tab} onChange={setTab} />

      {/* Secure connection request */}
      <ConnectionSheet
        device={incoming}
        onAccept={() => {
          setIncoming(null)
          setTab('chat')
        }}
        onDecline={() => setIncoming(null)}
      />
    </div>
  )
}
