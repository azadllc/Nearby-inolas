'use client'

import { MessageCircle, Radar, Settings } from 'lucide-react'
import { cn } from '@/lib/utils'

export type TabKey = 'home' | 'chat' | 'settings'

const tabs = [
  { key: 'home' as const, label: 'Discover', icon: Radar },
  { key: 'chat' as const, label: 'Share', icon: MessageCircle },
  { key: 'settings' as const, label: 'Settings', icon: Settings },
]

interface BottomNavProps {
  active: TabKey
  onChange: (tab: TabKey) => void
}

export function BottomNav({ active, onChange }: BottomNavProps) {
  return (
    <nav className="sticky bottom-0 z-30 border-t border-border bg-card/80 backdrop-blur-lg">
      <div className="mx-auto flex max-w-md items-center justify-around px-2 py-2">
        {tabs.map(({ key, label, icon: Icon }) => {
          const isActive = active === key
          return (
            <button
              key={key}
              type="button"
              onClick={() => onChange(key)}
              aria-current={isActive ? 'page' : undefined}
              className={cn(
                'flex flex-1 flex-col items-center gap-1 rounded-2xl py-2 transition-colors',
                isActive ? 'text-primary' : 'text-muted-foreground',
              )}
            >
              <span
                className={cn(
                  'flex h-9 w-14 items-center justify-center rounded-full transition-colors',
                  isActive && 'bg-accent',
                )}
              >
                <Icon className="size-5" />
              </span>
              <span className="text-[11px] font-semibold">{label}</span>
            </button>
          )
        })}
      </div>
    </nav>
  )
}
