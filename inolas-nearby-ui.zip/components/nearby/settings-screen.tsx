'use client'

import {
  Bluetooth,
  Check,
  ChevronRight,
  FileText,
  History,
  Image as ImageIcon,
  Package,
  Pencil,
  Settings as SettingsIcon,
  Video,
  Wifi,
} from 'lucide-react'
import { useState } from 'react'
import { transferHistory, type TransferRecord } from './data'
import { EmptyState } from './empty-state'
import { cn } from '@/lib/utils'

function Toggle({
  checked,
  onChange,
  label,
}: {
  checked: boolean
  onChange: (v: boolean) => void
  label: string
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={cn(
        'relative h-7 w-12 shrink-0 rounded-full transition-colors',
        checked ? 'bg-primary' : 'bg-muted',
      )}
    >
      <span
        className={cn(
          'absolute top-1 size-5 rounded-full bg-white shadow-sm transition-transform',
          checked ? 'translate-x-6' : 'translate-x-1',
        )}
      />
    </button>
  )
}

const kindConfig = {
  photo: { icon: ImageIcon, accent: '279' },
  video: { icon: Video, accent: '320' },
  document: { icon: FileText, accent: '200' },
  apk: { icon: Package, accent: '150' },
} as const

function HistoryRow({ record }: { record: TransferRecord }) {
  const { icon: Icon, accent } = kindConfig[record.kind]
  return (
    <div className="flex items-center gap-3 p-3.5">
      <span
        className="flex size-10 shrink-0 items-center justify-center rounded-xl text-white"
        style={{
          background: `linear-gradient(135deg, oklch(0.62 0.2 ${accent}), oklch(0.5 0.24 ${Number(accent) + 30}))`,
        }}
      >
        <Icon className="size-5" />
      </span>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-semibold text-foreground">{record.fileName}</p>
        <p className="truncate text-xs text-muted-foreground">
          {record.peer} · {record.size} · {record.time}
        </p>
      </div>
      <span className="flex size-6 shrink-0 items-center justify-center rounded-full bg-success/15 text-success">
        <Check className="size-4" />
      </span>
    </div>
  )
}

export function SettingsScreen() {
  const [displayName, setDisplayName] = useState('Priya Sharma')
  const [editing, setEditing] = useState(false)
  const [autoAccept, setAutoAccept] = useState(false)
  const history = transferHistory

  return (
    <div className="space-y-5">
      {/* Settings group */}
      <section>
        <h2 className="mb-3 px-1 text-sm font-bold tracking-tight text-foreground">Settings</h2>
        <div className="divide-y divide-border overflow-hidden rounded-3xl border border-border bg-card">
          {/* Display name */}
          <div className="flex items-center gap-3 p-4">
            <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-accent text-accent-foreground">
              <Pencil className="size-5" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-medium text-muted-foreground">Nearby Display Name</p>
              {editing ? (
                <input
                  autoFocus
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  onBlur={() => setEditing(false)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.nativeEvent.isComposing) setEditing(false)
                  }}
                  className="w-full border-b border-primary bg-transparent text-sm font-semibold text-foreground outline-none"
                />
              ) : (
                <p className="truncate text-sm font-semibold text-foreground">{displayName}</p>
              )}
            </div>
            <button
              type="button"
              onClick={() => setEditing((v) => !v)}
              className="shrink-0 rounded-full bg-secondary px-3 py-1.5 text-xs font-semibold text-secondary-foreground transition-colors hover:bg-muted"
            >
              {editing ? 'Save' : 'Edit'}
            </button>
          </div>

          {/* Auto-accept */}
          <div className="flex items-center gap-3 p-4">
            <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-accent text-accent-foreground">
              <Check className="size-5" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold text-foreground">Auto-Accept Transfers</p>
              <p className="text-xs text-muted-foreground text-pretty">
                Skip the confirmation for trusted devices
              </p>
            </div>
            <Toggle checked={autoAccept} onChange={setAutoAccept} label="Auto-accept transfers" />
          </div>

          {/* Device settings shortcuts */}
          {[
            { label: 'Bluetooth Settings', icon: Bluetooth },
            { label: 'Wi-Fi Direct Settings', icon: Wifi },
            { label: 'App Permissions', icon: SettingsIcon },
          ].map(({ label, icon: Icon }) => (
            <button
              key={label}
              type="button"
              className="flex w-full items-center gap-3 p-4 text-left transition-colors hover:bg-secondary/60"
            >
              <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-secondary text-foreground">
                <Icon className="size-5" />
              </span>
              <span className="flex-1 text-sm font-semibold text-foreground">{label}</span>
              <ChevronRight className="size-4 text-muted-foreground" />
            </button>
          ))}
        </div>
      </section>

      {/* Transfer history */}
      <section>
        <div className="mb-3 flex items-center justify-between px-1">
          <h2 className="flex items-center gap-2 text-sm font-bold tracking-tight text-foreground">
            <History className="size-4 text-primary" />
            Transfer History
          </h2>
          {history.length > 0 && (
            <button type="button" className="text-xs font-semibold text-primary">
              Clear all
            </button>
          )}
        </div>

        {history.length > 0 ? (
          <div className="divide-y divide-border overflow-hidden rounded-3xl border border-border bg-card">
            {history.map((record) => (
              <HistoryRow key={record.id} record={record} />
            ))}
          </div>
        ) : (
          <div className="rounded-3xl border border-dashed border-border bg-card/50">
            <EmptyState
              icon={History}
              title="No transfers yet"
              description="Files you send and receive offline will appear here."
            />
          </div>
        )}
      </section>
    </div>
  )
}
