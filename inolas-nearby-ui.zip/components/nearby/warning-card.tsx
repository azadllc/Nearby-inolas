'use client'

import { TriangleAlert } from 'lucide-react'

interface WarningCardProps {
  bluetooth: boolean
  wifi: boolean
  onEnable: () => void
}

export function WarningCard({ bluetooth, wifi, onEnable }: WarningCardProps) {
  if (bluetooth && wifi) return null

  const missing = [!bluetooth && 'Bluetooth', !wifi && 'Wi-Fi Direct'].filter(Boolean).join(' & ')

  return (
    <div className="animate-inolas-rise flex items-center gap-3 rounded-3xl border border-warning/30 bg-warning/10 p-4">
      <span className="flex size-10 shrink-0 items-center justify-center rounded-2xl bg-warning/20 text-warning">
        <TriangleAlert className="size-5" />
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-semibold text-foreground">{missing} turned off</p>
        <p className="text-xs text-muted-foreground text-pretty">
          Turn it back on so nearby devices can find you.
        </p>
      </div>
      <button
        type="button"
        onClick={onEnable}
        className="shrink-0 rounded-full bg-primary px-4 py-2 text-xs font-semibold text-primary-foreground transition-all hover:brightness-110 active:scale-95"
      >
        Enable
      </button>
    </div>
  )
}
