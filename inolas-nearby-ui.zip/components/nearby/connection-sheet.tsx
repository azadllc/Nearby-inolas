'use client'

import { ShieldCheck, Smartphone, X } from 'lucide-react'
import type { NearbyDevice } from './data'
import { ProfileAvatar } from './profile-avatar'

interface ConnectionSheetProps {
  device: NearbyDevice | null
  onAccept: () => void
  onDecline: () => void
}

export function ConnectionSheet({ device, onAccept, onDecline }: ConnectionSheetProps) {
  if (!device) return null

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center"
      role="dialog"
      aria-modal="true"
      aria-label="Incoming connection request"
    >
      {/* Scrim */}
      <button
        type="button"
        aria-label="Dismiss"
        onClick={onDecline}
        className="animate-inolas-fade absolute inset-0 bg-foreground/40 backdrop-blur-sm"
      />

      {/* Sheet */}
      <div className="animate-inolas-sheet-up relative z-10 w-full max-w-md rounded-t-[2rem] border border-border bg-card p-5 pb-8 shadow-2xl">
        <div className="mx-auto mb-5 h-1.5 w-12 rounded-full bg-border" />

        <button
          type="button"
          onClick={onDecline}
          aria-label="Close"
          className="absolute right-4 top-5 flex size-8 items-center justify-center rounded-full bg-secondary text-muted-foreground transition-colors hover:bg-muted"
        >
          <X className="size-4" />
        </button>

        <div className="flex flex-col items-center text-center">
          <span className="mb-3 flex items-center gap-1.5 rounded-full bg-accent px-3 py-1 text-xs font-semibold text-accent-foreground">
            <ShieldCheck className="size-3.5" />
            Secure connection
          </span>

          <ProfileAvatar
            name={device.displayName}
            accent={device.accent}
            src={device.avatarUrl}
            size="lg"
          />

          <h2 className="mt-3 text-lg font-bold tracking-tight text-foreground text-balance">
            {device.displayName} wants to connect
          </h2>
          <p className="mt-1 flex items-center gap-1.5 text-sm text-muted-foreground">
            <Smartphone className="size-4" />
            {device.deviceName} · {device.distance} away
          </p>

          <p className="mt-4 rounded-2xl bg-secondary px-4 py-3 text-xs text-muted-foreground text-pretty">
            Accepting establishes an encrypted offline channel. No data leaves your local
            connection.
          </p>
        </div>

        <div className="mt-6 flex gap-3">
          <button
            type="button"
            onClick={onDecline}
            className="flex-1 rounded-2xl border border-border bg-transparent py-3.5 text-sm font-semibold text-foreground transition-colors hover:bg-secondary active:scale-[0.98]"
          >
            Decline
          </button>
          <button
            type="button"
            onClick={onAccept}
            className="flex-[1.4] rounded-2xl bg-primary py-3.5 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/30 transition-all hover:brightness-110 active:scale-[0.98]"
          >
            Accept
          </button>
        </div>
      </div>
    </div>
  )
}
