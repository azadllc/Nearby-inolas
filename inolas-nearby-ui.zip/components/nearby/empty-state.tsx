import type { LucideIcon } from 'lucide-react'

interface EmptyStateProps {
  icon: LucideIcon
  title: string
  description: string
  action?: React.ReactNode
}

export function EmptyState({ icon: Icon, title, description, action }: EmptyStateProps) {
  return (
    <div className="animate-inolas-fade flex flex-col items-center justify-center px-6 py-12 text-center">
      {/* Layered concentric illustration */}
      <div className="relative mb-6 flex size-28 items-center justify-center">
        <span className="absolute size-28 rounded-full bg-primary/5" />
        <span className="absolute size-20 rounded-full bg-primary/10" />
        <span className="absolute size-14 rounded-full bg-primary/15" />
        <span className="relative flex size-14 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg shadow-primary/25">
          <Icon className="size-6" />
        </span>
      </div>
      <h3 className="text-base font-bold tracking-tight text-foreground">{title}</h3>
      <p className="mx-auto mt-1.5 max-w-[16rem] text-pretty text-sm text-muted-foreground">
        {description}
      </p>
      {action ? <div className="mt-5">{action}</div> : null}
    </div>
  )
}
