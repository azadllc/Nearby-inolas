// Central mock data + types for Inolas Nearby.
// Swap these out for real Bluetooth / Wi-Fi Direct / Supabase data later.

export type SignalStrength = 'strong' | 'medium' | 'weak'

export interface NearbyDevice {
  id: string
  displayName: string
  username: string
  deviceName: string
  distance: string
  signal: SignalStrength
  /** Optional avatar image url. Falls back to initials when absent. */
  avatarUrl?: string
  accent: string // hue for the initials avatar gradient
}

export interface ChatMessage {
  id: string
  author: 'me' | 'them'
  text: string
  time: string
  status?: 'sending' | 'sent' | 'delivered' | 'read'
}

export interface TransferRecord {
  id: string
  fileName: string
  kind: 'photo' | 'video' | 'document' | 'apk'
  size: string
  peer: string
  time: string
}

export const nearbyDevices: NearbyDevice[] = [
  {
    id: 'd1',
    displayName: 'Aarav Mehta',
    username: '@aarav',
    deviceName: 'Pixel 9 Pro',
    distance: '1.2 m',
    signal: 'strong',
    accent: '279',
  },
  {
    id: 'd2',
    displayName: 'Sofia Rossi',
    username: '@sofia.r',
    deviceName: 'Galaxy S24',
    distance: '3.8 m',
    signal: 'medium',
    accent: '320',
  },
  {
    id: 'd3',
    displayName: 'Leo Tanaka',
    username: '@leo_t',
    deviceName: 'OnePlus 12',
    distance: '6.5 m',
    signal: 'weak',
    accent: '200',
  },
  {
    id: 'd4',
    displayName: 'Maya Okonkwo',
    username: '@maya.dev',
    deviceName: 'Nothing Phone 2',
    distance: '2.1 m',
    signal: 'strong',
    accent: '150',
  },
]

export const chatMessages: ChatMessage[] = [
  {
    id: 'm1',
    author: 'them',
    text: 'Hey! Sending over the trip photos now 📸',
    time: '10:24',
  },
  {
    id: 'm2',
    author: 'me',
    text: 'Perfect, my Wi-Fi is down so this is clutch 🙌',
    time: '10:24',
    status: 'read',
  },
  {
    id: 'm3',
    author: 'them',
    text: 'No internet needed here 😎 all peer-to-peer',
    time: '10:25',
  },
  {
    id: 'm4',
    author: 'me',
    text: 'Got the first batch. Ready for the videos too 🎬',
    time: '10:26',
    status: 'delivered',
  },
]

export const transferHistory: TransferRecord[] = [
  {
    id: 't1',
    fileName: 'Sunset_Beach.jpg',
    kind: 'photo',
    size: '4.2 MB',
    peer: 'Aarav Mehta',
    time: 'Today, 10:24',
  },
  {
    id: 't2',
    fileName: 'Team_Standup.mp4',
    kind: 'video',
    size: '128 MB',
    peer: 'Sofia Rossi',
    time: 'Today, 09:10',
  },
  {
    id: 't3',
    fileName: 'Q3_Report.pdf',
    kind: 'document',
    size: '2.1 MB',
    peer: 'Maya Okonkwo',
    time: 'Yesterday, 18:45',
  },
  {
    id: 't4',
    fileName: 'inolas-nearby.apk',
    kind: 'apk',
    size: '38 MB',
    peer: 'Leo Tanaka',
    time: 'Yesterday, 16:02',
  },
]
