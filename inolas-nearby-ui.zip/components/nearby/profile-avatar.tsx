import { cn } from '@/lib/utils'

interface ProfileAvatarProps {
  name: string
  accent?: string
  src?: string
  size?: 'sm' | 'md' | 'lg'
  className?: string
}

const sizeMap = {
  sm: 'size-10 text-sm',
  md: 'size-12 text-base',
  lg: 'size-16 text-xl',
}

function initials(name: string) {
  return name
    .split(' ')
    .map((part) => part[0])
    .slice(0, 2)
    .join('')
    .toUpperCase()
}

export function ProfileAvatar({
  name,
  accent = '279',
  src,
  size = 'md',
  className,
}: ProfileAvatarProps) {
  return (
    <div
      className={cn(
        'relative flex shrink-0 items-center justify-center overflow-hidden rounded-2xl font-semibold text-white',
        sizeMap[size],
        className,
      )}
      style={{
        background: src
          ? undefined
          : `linear-gradient(135deg, oklch(0.62 0.2 ${accent}), oklch(0.5 0.24 ${Number(accent) + 30}))`,
      }}
    >
      {src ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={src || '/placeholder.svg'} alt={name} className="size-full object-cover" />
      ) : (
        <span className="tracking-tight">{initials(name)}</span>
      )}
    </div>
  )
}
