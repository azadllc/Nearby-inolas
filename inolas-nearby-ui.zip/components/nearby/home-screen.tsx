'use client'

import { RadioTower, Users } from 'lucide-react'
import { useMemo } from 'react'
import { nearbyDevices, type NearbyDevice } from './data'
import { DeviceCard } from './device-card'
import { DiscoverButton } from './discover-button'
import { EmptyState } from './empty-state'
import { StatusBar, type ConnectivityState } from './status-bar'
import { WarningCard } from './warning-card'

interface HomeScreenProps {
  connectivity: ConnectivityState
  onConnectivityChange: (next: ConnectivityState) => void
  scanning: boolean
  onScanToggle: () => void
  onSelectDevice: (device: NearbyDevice) => void
}

export function HomeScreen({
  connectivity,
  onConnectivityChange,
  scanning,
  onScanToggle,
  onSelectDevice,
}: HomeScreenProps) {
  const radiosOff = !connectivity.bluetooth && !connectivity.wifi
  const devices = useMemo(
    () => (scanning && !radiosOff ? nearbyDevices : []),
    [scanning, radiosOff],
  )

  return (
    <div className="space-y-5">
      <StatusBar state={connectivity} onChange={onConnectivityChange} />

      <WarningCard
        bluetooth={connectivity.bluetooth}
        wifi={connectivity.wifi}
        onEnable={() => onConnectivityChange({ ...connectivity, bluetooth: true, wifi: true })}
      />

      <div className="rounded-[2rem] border border-border bg-card p-4">
        <DiscoverButton scanning={scanning} disabled={radiosOff} onToggle={onScanToggle} />
      </div>

      <section>
        <div className="mb-3 flex items-center justify-between px-1">
          <h2 className="flex items-center gap-2 text-sm font-bold tracking-tight text-foreground">
            <Users className="size-4 text-primary" />
            Nearby Devices
          </h2>
          {devices.length > 0 && (
            <span className="rounded-full bg-accent px-2.5 py-0.5 text-xs font-semibold text-accent-foreground">
              {devices.length} found
            </span>
          )}
        </div>

        {devices.length > 0 ? (
          <div className="space-y-2.5">
            {devices.map((device, i) => (
              <DeviceCard
                key={device.id}
                device={device}
                onConnect={onSelectDevice}
                style={{ animationDelay: `${i * 70}ms` }}
              />
            ))}
          </div>
        ) : (
          <div className="rounded-3xl border border-dashed border-border bg-card/50">
            <EmptyState
              icon={RadioTower}
              title={radiosOff ? 'Radios are off' : 'No devices yet'}
              description={
                radiosOff
                  ? 'Enable Bluetooth or Wi-Fi Direct, then start discovering.'
                  : 'Tap Discover to start scanning for people around you.'
              }
            />
          </div>
        )}
      </section>
    </div>
  )
}
