'use client'

import { Radar } from 'lucide-react'
import { cn } from '@/lib/utils'

interface DiscoverButtonProps {
  scanning: boolean
  disabled?: boolean
  onToggle: () => void
}

export function DiscoverButton({ scanning, disabled, onToggle }: DiscoverButtonProps) {
  return (
    <div className="flex flex-col items-center gap-4 py-4">
      <div className="relative flex size-56 items-center justify-center">
        {/* Radiating pulse rings while scanning */}
        {scanning && !disabled && (
          <>
            <span className="animate-inolas-ping absolute inline-flex size-40 rounded-full bg-primary/25" />
            <span
              className="animate-inolas-ping absolute inline-flex size-40 rounded-full bg-primary/20"
              style={{ animationDelay: '0.8s' }}
            />
            <span
              className="animate-inolas-ping absolute inline-flex size-40 rounded-full bg-primary/15"
              style={{ animationDelay: '1.6s' }}
            />
          </>
        )}

        {/* Rotating sweep ring */}
        <div
          className={cn(
            'absolute size-52 rounded-full border border-dashed border-primary/25',
            scanning && !disabled && 'animate-inolas-spin',
          )}
        />
        <div className="absolute size-40 rounded-full border border-border" />

        <button
          type="button"
          onClick={onToggle}
          disabled={disabled}
          aria-label={scanning ? 'Stop discovering' : 'Discover nearby devices'}
          className={cn(
            'relative z-10 flex size-32 flex-col items-center justify-center gap-1.5 rounded-full text-primary-foreground shadow-lg shadow-primary/30 transition-all active:scale-95',
            disabled
              ? 'cursor-not-allowed bg-muted text-muted-foreground shadow-none'
              : 'bg-primary hover:brightness-110',
          )}
        >
          <Radar className={cn('size-9', scanning && !disabled && 'animate-pulse')} />
          <span className="px-2 text-center text-xs font-semibold leading-tight text-balance">
            {disabled ? 'Unavailable' : scanning ? 'Scanning…' : 'Discover'}
          </span>
        </button>
      </div>

      <div className="text-center">
        <h2 className="text-lg font-bold tracking-tight text-foreground">
          {disabled
            ? 'Turn on a radio to scan'
            : scanning
              ? 'Looking for people nearby'
              : 'Discover Nearby'}
        </h2>
        <p className="mx-auto mt-1 max-w-xs text-pretty text-sm text-muted-foreground">
          {disabled
            ? 'Enable Bluetooth or Wi-Fi Direct to find devices around you.'
            : 'Tap the beacon to broadcast and find people around you — fully offline.'}
        </p>
      </div>
    </div>
  )
}
