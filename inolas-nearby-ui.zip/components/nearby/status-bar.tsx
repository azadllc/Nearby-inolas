'use client'

import { Bluetooth, Eye, EyeOff, Wifi } from 'lucide-react'
import { cn } from '@/lib/utils'

interface StatusChipProps {
  label: string
  active: boolean
  icon: React.ReactNode
  onToggle: () => void
}

function StatusChip({ label, active, icon, onToggle }: StatusChipProps) {
  return (
    <button
      type="button"
      onClick={onToggle}
      aria-pressed={active}
      className={cn(
        'flex flex-1 flex-col items-center gap-1.5 rounded-2xl border p-3 transition-all active:scale-[0.97]',
        active
          ? 'border-primary/30 bg-accent text-accent-foreground'
          : 'border-border bg-card text-muted-foreground',
      )}
    >
      <span
        className={cn(
          'flex size-9 items-center justify-center rounded-xl transition-colors',
          active ? 'bg-primary text-primary-foreground' : 'bg-secondary',
        )}
      >
        {icon}
      </span>
      <span className="text-xs font-semibold text-foreground">{label}</span>
      <span
        className={cn(
          'flex items-center gap-1 text-[10px] font-medium',
          active ? 'text-primary' : 'text-muted-foreground',
        )}
      >
        <span
          className={cn(
            'size-1.5 rounded-full',
            active ? 'bg-primary' : 'bg-muted-foreground/50',
          )}
        />
        {active ? 'ON' : 'OFF'}
      </span>
    </button>
  )
}

export interface ConnectivityState {
  bluetooth: boolean
  wifi: boolean
  visible: boolean
}

interface StatusBarProps {
  state: ConnectivityState
  onChange: (next: ConnectivityState) => void
}

export function StatusBar({ state, onChange }: StatusBarProps) {
  return (
    <div className="flex gap-2.5">
      <StatusChip
        label="Bluetooth"
        active={state.bluetooth}
        icon={<Bluetooth className="size-5" />}
        onToggle={() => onChange({ ...state, bluetooth: !state.bluetooth })}
      />
      <StatusChip
        label="Wi-Fi Direct"
        active={state.wifi}
        icon={<Wifi className="size-5" />}
        onToggle={() => onChange({ ...state, wifi: !state.wifi })}
      />
      <StatusChip
        label="Visible"
        active={state.visible}
        icon={state.visible ? <Eye className="size-5" /> : <EyeOff className="size-5" />}
        onToggle={() => onChange({ ...state, visible: !state.visible })}
      />
    </div>
  )
}
