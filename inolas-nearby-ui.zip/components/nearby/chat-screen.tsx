'use client'

import {
  Check,
  CheckCheck,
  FileText,
  Image as ImageIcon,
  Package,
  Paperclip,
  Send,
  Smile,
  Video,
  WifiOff,
} from 'lucide-react'
import { chatMessages, type ChatMessage } from './data'
import { ProfileAvatar } from './profile-avatar'
import { cn } from '@/lib/utils'

const quickShare = [
  { label: 'Photos', icon: ImageIcon, accent: '279' },
  { label: 'Videos', icon: Video, accent: '320' },
  { label: 'Documents', icon: FileText, accent: '200' },
  { label: 'APK Files', icon: Package, accent: '150' },
] as const

function MessageStatus({ status }: { status?: ChatMessage['status'] }) {
  if (!status) return null
  if (status === 'read') return <CheckCheck className="size-3.5 text-accent-foreground" />
  if (status === 'delivered') return <CheckCheck className="size-3.5 opacity-70" />
  return <Check className="size-3.5 opacity-70" />
}

function Bubble({ message }: { message: ChatMessage }) {
  const mine = message.author === 'me'
  return (
    <div className={cn('flex animate-inolas-rise', mine ? 'justify-end' : 'justify-start')}>
      <div
        className={cn(
          'max-w-[78%] rounded-3xl px-4 py-2.5 text-sm leading-relaxed',
          mine
            ? 'rounded-br-lg bg-primary text-primary-foreground'
            : 'rounded-bl-lg bg-card text-card-foreground border border-border',
        )}
      >
        <p className="text-pretty">{message.text}</p>
        <div
          className={cn(
            'mt-1 flex items-center justify-end gap-1 text-[10px]',
            mine ? 'text-primary-foreground/70' : 'text-muted-foreground',
          )}
        >
          <span>{message.time}</span>
          {mine && <MessageStatus status={message.status} />}
        </div>
      </div>
    </div>
  )
}

export function ChatScreen() {
  return (
    <div className="space-y-5">
      {/* Chat header */}
      <div className="flex items-center gap-3 rounded-3xl border border-border bg-card p-3">
        <ProfileAvatar name="Aarav Mehta" accent="279" />
        <div className="min-w-0 flex-1">
          <p className="truncate font-semibold text-foreground">Aarav Mehta</p>
          <p className="flex items-center gap-1 text-xs text-success">
            <span className="size-1.5 rounded-full bg-success" />
            Connected · Offline channel
          </p>
        </div>
        <span className="flex items-center gap-1 rounded-full bg-secondary px-2.5 py-1 text-[11px] font-medium text-muted-foreground">
          <WifiOff className="size-3.5" />
          No internet
        </span>
      </div>

      {/* Messages */}
      <div className="space-y-2.5 rounded-3xl border border-border bg-secondary/40 p-4">
        <p className="mx-auto w-fit rounded-full bg-card px-3 py-1 text-[11px] font-medium text-muted-foreground">
          Encrypted peer-to-peer · Today
        </p>
        {chatMessages.map((m) => (
          <Bubble key={m.id} message={m} />
        ))}
      </div>

      {/* Quick share grid */}
      <section>
        <h2 className="mb-3 px-1 text-sm font-bold tracking-tight text-foreground">
          Quick Share
        </h2>
        <div className="grid grid-cols-4 gap-2.5">
          {quickShare.map(({ label, icon: Icon, accent }) => (
            <button
              key={label}
              type="button"
              className="flex flex-col items-center gap-2 rounded-2xl border border-border bg-card p-3 transition-all hover:border-primary/30 active:scale-95"
            >
              <span
                className="flex size-10 items-center justify-center rounded-xl text-white"
                style={{
                  background: `linear-gradient(135deg, oklch(0.62 0.2 ${accent}), oklch(0.5 0.24 ${Number(accent) + 30}))`,
                }}
              >
                <Icon className="size-5" />
              </span>
              <span className="text-[11px] font-medium text-foreground">{label}</span>
            </button>
          ))}
        </div>
      </section>

      {/* Composer */}
      <div className="flex items-center gap-2 rounded-full border border-border bg-card p-1.5">
        <button
          type="button"
          aria-label="Attach file"
          className="flex size-10 shrink-0 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-secondary"
        >
          <Paperclip className="size-5" />
        </button>
        <input
          type="text"
          placeholder="Send an offline message…"
          className="min-w-0 flex-1 bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
        />
        <button
          type="button"
          aria-label="Emoji"
          className="flex size-10 shrink-0 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-secondary"
        >
          <Smile className="size-5" />
        </button>
        <button
          type="button"
          aria-label="Send message"
          className="flex size-10 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground transition-all hover:brightness-110 active:scale-95"
        >
          <Send className="size-4" />
        </button>
      </div>
    </div>
  )
}
