'use client'

import { Signal, SignalHigh, SignalLow, SignalMedium, Smartphone } from 'lucide-react'
import type { NearbyDevice } from './data'
import { ProfileAvatar } from './profile-avatar'
import { cn } from '@/lib/utils'

const signalConfig = {
  strong: { icon: SignalHigh, label: 'Strong', className: 'text-success' },
  medium: { icon: SignalMedium, label: 'Fair', className: 'text-warning' },
  weak: { icon: SignalLow, label: 'Weak', className: 'text-muted-foreground' },
} as const

interface DeviceCardProps {
  device: NearbyDevice
  onConnect: (device: NearbyDevice) => void
  style?: React.CSSProperties
}

export function DeviceCard({ device, onConnect, style }: DeviceCardProps) {
  const signal = signalConfig[device.signal] ?? { icon: Signal, label: '', className: '' }
  const SignalIcon = signal.icon

  return (
    <button
      type="button"
      onClick={() => onConnect(device)}
      style={style}
      className="animate-inolas-rise flex w-full items-center gap-3.5 rounded-3xl border border-border bg-card p-3.5 text-left transition-all hover:border-primary/30 hover:shadow-md active:scale-[0.99]"
    >
      <ProfileAvatar name={device.displayName} accent={device.accent} src={device.avatarUrl} />

      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <p className="truncate font-semibold text-foreground">{device.displayName}</p>
          <span className="truncate text-xs text-muted-foreground">{device.username}</span>
        </div>
        <div className="mt-0.5 flex items-center gap-1.5 text-xs text-muted-foreground">
          <Smartphone className="size-3.5 shrink-0" />
          <span className="truncate">{device.deviceName}</span>
        </div>
      </div>

      <div className="flex shrink-0 flex-col items-end gap-1.5">
        <span className="rounded-full bg-secondary px-2.5 py-1 text-xs font-semibold text-secondary-foreground">
          {device.distance}
        </span>
        <span className={cn('flex items-center gap-1 text-[11px] font-medium', signal.className)}>
          <SignalIcon className="size-3.5" />
          {signal.label}
        </span>
      </div>
    </button>
  )
}
